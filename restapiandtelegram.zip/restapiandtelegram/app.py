from datetime import date
from flask import Flask, render_template, request, redirect
import requests

app = Flask(__name__)


@app.route('/')
@app.route('/home')
def get_all_products():
    res = requests.get('https://fakestoreapi.com/products')
    products = res.json()
    return render_template('components/product_card.html', product_list=products)


@app.route('/product_detail')
def get_product_detail():
    product_id = request.args.get('id')
    res = requests.get(f"https://fakestoreapi.com/products/{product_id}")
    product = res.json()
    return render_template('layout/product_detail.html', product_detail=product)


@app.route('/checkout')
def checkout():
    product_id = request.args.get('id')
    res = requests.get(f"https://fakestoreapi.com/products/{product_id}")
    product = res.json()
    return render_template('layout/confirm_booking.html', product_detail=product)


@app.post('/confirm_checkout')
def confirm_checkout():
    product_id = request.form.get('id')
    res = requests.get(f"https://fakestoreapi.com/products/{product_id}")
    product = res.json()

    name = request.form.get('name')
    phone = request.form.get('phone')
    email = request.form.get('email')
    address = request.form.get('address')
    quantity = request.form.get('quantity')

    if not quantity:
        quantity = 1
    else:
        quantity = int(quantity)

    total_price = product['price'] * quantity

    msg = (
        "<code> =========[ New Order ]========= </code>\n"
        "<code> - Name: {name}</code>\n"
        "<code> - Phone: {phone}</code>\n"
        "<code> - Email: {email}</code>\n"
        "<code> - Address: {address}</code>\n"
        "<code> - Date: {date}</code>\n"
        "<code> =========[ Order Detail ]========= </code>\n"
        "<b>🔔 Order Detail 🔔</b>\n"
        "<code>1. {product_name} {quantity}x{price} = ${total_price}</code>\n"
    ).format(
        name=name,
        phone=phone,
        email=email,
        address=address,
        date=date.today(),
        product_name=product['title'],
        quantity=quantity,
        price=product['price'],
        total_price=total_price
    )

    send_notification(msg)

    return redirect('/')


def send_notification(msg):
    bot_token = '6453746406:AAH_0KulHrFj2Kl3Jh2-OTAbBDqWL0chT7M'
    chat_id = '@menkong'

    url = f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={requests.utils.quote(msg)}&parse_mode=HTML"
    res = requests.get(url)
    return res


if __name__ == '__main__':
    app.run(debug=True)
